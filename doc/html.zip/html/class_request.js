var class_request =
[
    [ "getDataType", "class_request.html#ae8bce727d16260b41c948c6c2a36f780", null ],
    [ "getExpression", "class_request.html#a8e1af39bece43ea8faeebb34d6588737", null ],
    [ "getLabel", "class_request.html#afc72cd1fa351f478ba86a82df4f26fad", null ],
    [ "getValue", "class_request.html#a9846ce56327df5c2e1b5f817eaa1f2a1", null ],
    [ "setDataType", "class_request.html#ae34211eb5432154dee68d2385167aa10", null ],
    [ "setExpression", "class_request.html#ac8f27dc1acdcbc921166f35c1ea8d697", null ],
    [ "setLabel", "class_request.html#abb8ae6f91db885861ee829cd36cc83dc", null ],
    [ "setValue", "class_request.html#a1fca682005ae0546da256dfd7c85cf18", null ],
    [ "dataType", "class_request.html#af5ecba97b6dc69d6e1ef18978bd0c503", null ],
    [ "expression", "class_request.html#a3ea54d4b4e71c1953be147216d957227", null ],
    [ "label", "class_request.html#aa182cfc7e8c607f1a734447dda978fe0", null ],
    [ "value", "class_request.html#aecbc9368c237981c2d361c0eb7c217c1", null ]
];