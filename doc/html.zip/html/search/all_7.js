var searchData=
[
  ['label_13',['label',['../class_request.html#aa182cfc7e8c607f1a734447dda978fe0',1,'Request']]],
  ['longallocator_14',['longAllocator',['../class_memory_map.html#ab9d42467379b2ab035f4d646df970b4e',1,'MemoryMap']]]
];
