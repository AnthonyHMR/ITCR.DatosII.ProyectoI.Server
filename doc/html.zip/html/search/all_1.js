var searchData=
[
  ['datatype_1',['dataType',['../class_request.html#af5ecba97b6dc69d6e1ef18978bd0c503',1,'Request']]],
  ['doubleallocator_2',['doubleAllocator',['../class_memory_map.html#a2f9aa1c90ac3576f6549788b90fe8a63',1,'MemoryMap']]]
];
