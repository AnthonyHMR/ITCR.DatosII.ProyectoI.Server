var searchData=
[
  ['floatallocator_4',['floatAllocator',['../class_memory_map.html#aafc763fc6437a8456e914d12e24153c7',1,'MemoryMap']]],
  ['freestorage_5',['freeStorage',['../class_memory_map.html#a625e73579be7b28f3278440a2235976c',1,'MemoryMap']]]
];
