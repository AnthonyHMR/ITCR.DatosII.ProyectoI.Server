var searchData=
[
  ['longallocator_51',['longAllocator',['../class_memory_map.html#ab9d42467379b2ab035f4d646df970b4e',1,'MemoryMap']]]
];
