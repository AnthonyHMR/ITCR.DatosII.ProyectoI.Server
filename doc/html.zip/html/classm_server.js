var classm_server =
[
    [ "mServer", "classm_server.html#acc91e4dc651f91ab7eb89a290bde6ad9", null ],
    [ "~mServer", "classm_server.html#af069458e075ea8634a33875e40e3615b", null ],
    [ "getMessage", "classm_server.html#ae745aecaf493608bf094071bc3a37633", null ],
    [ "requestWriter", "classm_server.html#a360a2505573322268e4f5d3f95cb7df9", null ],
    [ "runServer", "classm_server.html#a0a63cf2119815a02b17c45fa0d309e10", null ],
    [ "sendMessage", "classm_server.html#a6f7b34f319a9c90f669d16fd60408ee7", null ],
    [ "updateJsonFIle", "classm_server.html#a4b86eefc1477c98240db7428164d275b", null ]
];