var class_memory_map =
[
    [ "MemoryMap", "class_memory_map.html#a0c3e915224616dbce79be670e7b5eb7a", null ],
    [ "charAllocator", "class_memory_map.html#af03345cbfb83bd5256d261c0ed0023b0", null ],
    [ "doubleAllocator", "class_memory_map.html#a2f9aa1c90ac3576f6549788b90fe8a63", null ],
    [ "floatAllocator", "class_memory_map.html#aafc763fc6437a8456e914d12e24153c7", null ],
    [ "freeStorage", "class_memory_map.html#a625e73579be7b28f3278440a2235976c", null ],
    [ "intAllocator", "class_memory_map.html#acd2280f58e9f76dfc6847c83b67ad39b", null ],
    [ "longAllocator", "class_memory_map.html#ab9d42467379b2ab035f4d646df970b4e", null ],
    [ "placePetition", "class_memory_map.html#a3fc39d3eddc7e085ebadb413819ede2f", null ],
    [ "shortAllocator", "class_memory_map.html#a97269c5440f9d49d2e48d150ccf6e7c8", null ],
    [ "structAllocator", "class_memory_map.html#aebce1f2f645db0a29d24df64e6a21bcd", null ]
];